const W = d3.select('.chart').node().clientWidth;
const H = d3.select('.chart').node().clientHeight;
const margin = {t:50, r:50, b:50, l:50};
const w = W - margin.l - margin.r;
const h = H - margin.t - margin.b;

const plot = d3.select('.chart')
	.append('svg')
		.attr('width', W)
		.attr('height', H)
	.append('g')
		.attr('class','plot')
		.attr('transform',`translate(${margin.l}, ${margin.t})`);

const data = d3.csv('Argentina.csv', parse)
	.then(function(rows){

	////the game plan:
	////plot d.year on the x axis
	////plot d.children_with_HIV and d.total_population on the y axis
	////d.children_with_HIV and d.total_population will be two colors
})

console.log(data)

function parseRows(d){
	return {
		////find this data on line 173/174
		children_with_HIV:d.children_with_HIV,
		adults_with_HIV:d.adults_with_HIV,
		////
		total_population:d.total_population,
		year:+d.year,
		country_name:`$(d.country_name}`
	}
}

