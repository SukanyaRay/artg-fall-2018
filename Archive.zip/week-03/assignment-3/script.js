console.log('Assignment 3');

/*
 * Question 1: no code necessary, 
 * but feel free to use this space as a Javascript sandbox to check your answers
 */

/*
 * Question 2: control structures 
 */
{
	//2.1 
	/* YOUR CODE HERE*/

	//2.2
	/* YOUR CODE HERE*/

	//2.3
	const arr = [89, 23, 88, 54, 90, 0, 10];
	//Log out the content of this array using a for loop
	/* YOUR CODE HERE*/
}

/*
 * Question 3: no code necessary
 */

/*
 * Question 4: objects and arrays
 */

{
	//4.1
	const instructors = undefined; /* YOUR CODE HERE */

	//4.2 
	/* COMPLETE THE FUNCTION */
	function computeAvgTenure(){
		return;
	}

	//4.3
	/* YOUR CODE HERE */

}

