console.log('4-1');

//Selection exercise

//In #container-4, draw a chromatic scale

//In #container-5, experiment with drawing <svg> elements
//circle, rect, line, text, <g>