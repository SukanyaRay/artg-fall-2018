console.log('4-2');

const people = [
	{name: 'John K', category: 'instructor', age: 33},
	{name: 'Kerri S', category: 'student', age: 23},
	{name: 'Lenoard O', category: 'student', age: 45},
	{name: 'Mary A', category: 'student', age: 28},
	{name: 'Nathan C', category: 'student', age: 31},
	{name: 'Perry C', category: 'instructor', age: 33},
	{name: 'Sarah O', category: 'instructor', age: 41},
];

//Max age? Min age? Average age?
//Use d3.min, d3.max, and d3.mean combined with the accessor pattern


//How many students? How many instructors?
//Use array.forEach to tally up each


//Sort by last name initial? Use array.map and array.sort


//Average age of students only? Instructors only? Use array.filter


//Group instructors and students into two separate arrays