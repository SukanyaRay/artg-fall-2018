console.log('4-3');

//Visualizing array.random()