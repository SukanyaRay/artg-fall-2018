//Data import and parse
const data = d3.csv('../../data/nyc_permits.csv', parse); //JS Promise
const m = {t:50, r:50, b:50, l:50};

data.then(function(rows){

	const permitsByBorough = d3.nest()
		.key(function(d) { return d.job_type})
		.key(function(d) { return d.borough})
		.entries(rows); ////this is an array of data 

		console.log(permitsbyBorough);


	//NORMALIZE DATA:
	const rootNode = d3.hierarchy({ ////pass all data into d3.heirarchy to normalize it
		//// this makes a root node, because at first permitsbyBorough started off with two root nodes. They need a parent for this to work
		key: 'root',
		values: permitsByBorough ////this is that array from above, containing two objects
	}, function(d){return d.values})////looks at all the children in the tree

	//ADD BY COSTESTIMATE or COUNT ALL CHILDrEN
	//TOGGLE BETWEEN THESE TWO:
	const rootNodeByCost = rootNode.sum(function(d){return d.cost_estimate}); ////find the sum of your cost estimates
	const rootNodeByCount = rootNode.count(); ////counts all projects, regardless of value
	console.log(rootNode);


	//PARTITION
	//Size
	const partitionDiv = d3.select('#partition').node() //// a DOM node, not a selection
	const W = clientWidth;
	const H = clientHeight;
	const w = W - m.l - m.r;
	const h = H - m.t - m.b;

	const plot = d3.select('#partition')
		.append('svg')
		.attr('width', W)
		.attr('height', H)
		.append('g')
		.attr('transform' `translate(${m.l}, ${m.r})`);


	const partition = d3.partition() ////lets transform this data into a partition
		////d3.partition.size([size of thing])
		.size([w, h])

	const dataTransformed = partition(rootNode);
	draw(dataTransformed, plot);

	d3.select('#cost-vs-sqft').on('click', function(){
		rootNode.sum(function(d){return d.cost_estimate});
		const dataTransformed = partition(rootNode);
		draw(dataTransformed,plot);
	})
	d3.select('#per-sqft-vs-borough').on('click', function(){
		rootNode.count();
		const dataTransformed = partition(rootNode);
		draw(dataTransformed,plot)
	})

	
})

function draw(data, plot){
	//draw and updated DOM nodes based on data
	//enter exit update

	//create a rectangle for each child 
	//UPDATE
	const rectNodes = plot.selectAll('.node')
		.data(dataTransformed.descendants().filter(function(d){return d.depth<3})) ////return only depths 0,1,2
		
	//ENTER
	const rectNodesEnter = rectNodes.enter()
		.append('text');

		rectNodes.merge(labelNodesEnter)
		.text(function(d){return d.data.key})
		.attr('x', function(d){return d.x0})
		.attr('y', function(d){return d.y0})
		.attr('width', function(d){return d.x1 - d.x0})
		.attr('height', function(d){return d.y1 - d.y0})
		.style('fill', function(d){
			switch(d.depth){
				case 1: return 'red';
				case 2: return 'blue';
				case 0: return 'green';			}
		})
		.style('stroke','black')
		.style('stroke-width','1px');

	plot.selectAll('text')
		.data(
			dataTransformed
				.descendants()
				.filter(function(d){
					return d.depth<3
				})
		)
		.enter()
		.append('text')
		.text(function(d){return d.data.key})
		.attr('x', function(d){return (d.x0 + d.x1)/2})
		.attr('y', function(d){return (d.y0 + d.y1)/2})
		.attr('text-anchor','middle')


}

////////////////////////////////////////////////

////////////////////////////////////////////////


function parse(d){
	return {
		applicant_business_name:d.applicant_business_name,
		borough:d.borough,
		community_board:d.community_board,
		cost_estimate:+d.cost_estimate, //convert string to number
		enlargement:d.enlargement_flag_yes_no === "true"?true:false, //convert string to boolean
		address: `${d.job_location_house_number} ${d.job_location_street_name}`,
		job_number:+d.job_number,
		job_type:d.job_type,
		job_type2:d.job_type2,
		permit_type:d.permit_type,
		permit_issuance_date:new Date(d.permit_issuance_date),
		square_footage:+d.square_footage,
		cost_per_sqft: +d.square_footage > 0 ? (+d.cost_estimate /+d.square_footage):0
	}
}